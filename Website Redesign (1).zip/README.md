
  # Website Redesign

  This is a code bundle for Website Redesign. The original project is available at https://www.figma.com/design/OCYOXWq5l4tTAcp1aUxznx/Website-Redesign.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  