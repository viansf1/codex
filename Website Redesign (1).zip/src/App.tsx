import React, { useState } from 'react';
import { Phone, Mail, Menu, X } from 'lucide-react';
import CompanyInfo from './components/CompanyInfo';
import ProductTabs from './components/ProductTabs';
import PopularProducts from './components/PopularProducts';
import QuoteForm from './components/QuoteForm';
import Contacts from './components/Contacts';
import Footer from './components/Footer';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', { email, phone });
    // Handle form submission
  };

  return (
    <div className="min-h-screen bg-neutral-900" style={{ fontFamily: 'Geologica, sans-serif' }}>
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <span className="text-3xl font-bold text-[#c20e0d]">E&P</span>
              </div>
              <div className="hidden md:block">
                <div className="text-sm font-semibold text-neutral-900">
                  Износостойкие листы из Европы
                </div>
                <div className="text-xs text-neutral-600">
                  с доставкой на складов в России
                </div>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="text-xs text-neutral-500">Почта для заявок:</div>
                  <a href="mailto:zakaz@hard-met.ru" className="text-sm font-medium text-neutral-900 hover:text-[#c20e0d]">
                    zakaz@hard-met.ru
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="text-xs text-neutral-500">Отдел продаж:</div>
                  <a href="tel:+74991130000" className="text-sm font-medium text-neutral-900 hover:text-[#c20e0d]">
                    +7 (499) 113-00-00
                  </a>
                </div>
              </div>

              <button className="bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                Обратный звонок
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              className="lg:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-neutral-900" />
              ) : (
                <Menu className="w-6 h-6 text-neutral-900" />
              )}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden border-t border-neutral-200 py-4 space-y-4">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="text-xs text-neutral-500">Почта для заявок:</div>
                  <a href="mailto:zakaz@hard-met.ru" className="text-sm font-medium text-neutral-900">
                    zakaz@hard-met.ru
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-neutral-600" />
                <div>
                  <div className="text-xs text-neutral-500">Отдел продаж:</div>
                  <a href="tel:+74991130000" className="text-sm font-medium text-neutral-900">
                    +7 (499) 113-00-00
                  </a>
                </div>
              </div>

              <button className="w-full bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                Обратный звонок
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background with overlay */}
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1748946469976-d0f86878128c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXRzJTIwaW5kdXN0cmlhbCUyMHdhcmVob3VzZXxlbnwxfHx8fDE3Njk3MTI4OTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Industrial background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/95 via-neutral-900/85 to-neutral-900/75"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-white space-y-8">
              {/* Badge */}
              <div className="inline-block">
                <span className="bg-[#c20e0d] text-white font-bold px-4 py-2 rounded-full text-sm">
                  Листы в наличии и под заказ!
                </span>
              </div>

              {/* Headline */}
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold leading-tight mb-4">
                  Износостойкие листы в наличии на складе в РФ и Европе
                </h1>
                <p className="text-xl text-[#c20e0d] font-semibold">
                  по цене от 96 000₽ за лист
                </p>
              </div>

              {/* Benefits */}
              <div className="grid sm:grid-cols-3 gap-6">
                <div className="flex flex-col items-start">
                  <div className="bg-[#c20e0d] rounded-full p-3 mb-3">
                    <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-sm">
                    Быстрая доставка до вашего склада или объекта
                  </p>
                </div>

                <div className="flex flex-col items-start">
                  <div className="bg-[#c20e0d] rounded-full p-3 mb-3">
                    <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <p className="text-sm">
                    Наличие на складе в РФ и Европе
                  </p>
                </div>

                <div className="flex flex-col items-start">
                  <div className="bg-[#c20e0d] rounded-full p-3 mb-3">
                    <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                    </svg>
                  </div>
                  <p className="text-sm">
                    Лучшая цена за 1 лист и дополнительные скидки от объёма
                  </p>
                </div>
              </div>
            </div>

            {/* Right Content - Form */}
            <div className="relative">
              <div className="relative bg-white rounded-2xl shadow-2xl p-8">
                {/* Badge */}
                <div className="inline-block mb-6">
                  <span className="bg-[#c20e0d] text-white font-bold px-4 py-2 rounded-lg text-sm">
                    Акционное предложение на складе!
                  </span>
                </div>

                <h2 className="text-2xl font-bold text-neutral-900 mb-2">
                  Получите прайс-лист на износостойкие листы{' '}
                  <span className="text-[#c20e0d]">со склада:</span>
                </h2>

                <form onSubmit={handleSubmit} className="space-y-4 mt-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      Введите e-mail для получения:
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="mail@mail.ru"
                      className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      Введите Ваш номер телефона:
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+7 (000) 000-00-00"
                      className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-bold py-4 rounded-lg transition-colors"
                  >
                    Получить прайс-лист
                  </button>

                  <p className="text-xs text-neutral-500 text-center">
                    Нажимая на кнопку, вы соглашаетесь с политикой обработки данных
                  </p>
                </form>
              </div>

              {/* Product Image */}
              <div className="absolute -bottom-20 -right-12 hidden xl:block">
                <div className="relative">
                  <div className="absolute inset-0 bg-[#c20e0d] rounded-full blur-2xl opacity-20"></div>
                  <img
                    src="figma:asset/dd7735d3760b4af158f302cb32410ca891c105ba.png"
                    alt="Износостойкие листы"
                    className="relative w-72 h-72 object-contain"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Info Section */}
      <CompanyInfo />

      {/* Product Tabs Section */}
      <ProductTabs />

      {/* Popular Products Section */}
      <PopularProducts />

      {/* Quote Form Section */}
      <QuoteForm />

      {/* Contacts Section */}
      <Contacts />

      {/* Footer Section */}
      <Footer />
    </div>
  );
}