import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-neutral-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo and info */}
          <div className="text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start mb-2">
              <span className="text-2xl font-bold text-[#c20e0d]">E&P</span>
              <span className="text-white font-semibold">Износостойкие листы</span>
            </div>
            <p className="text-neutral-400 text-sm">
              © 2025 E&P. Все права защищены.
            </p>
          </div>

          {/* CTA Button */}
          <button className="bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-bold px-8 py-4 rounded-lg transition-colors shadow-lg hover:shadow-xl">
            Получить прайс
          </button>
        </div>

        {/* Links */}
        <div className="mt-8 pt-8 border-t border-neutral-800 flex flex-wrap justify-center md:justify-start gap-6 text-sm text-neutral-400">
          <a href="#" className="hover:text-white transition-colors">Политика конфиденциальности</a>
          <a href="#" className="hover:text-white transition-colors">Условия использования</a>
          <a href="#" className="hover:text-white transition-colors">О компании</a>
        </div>
      </div>
    </footer>
  );
}
