import React, { useState } from 'react';
import steelImage from 'figma:asset/ac246141915f354488b38f340ef005ca7efe90e8.png';

interface ProductData {
  name: string;
  grades: string;
  country: string;
  hardness: string;
  thickness: string;
  sizes: string[];
}

const productsData: Record<string, ProductData> = {
  dillidur: {
    name: 'Dillidur',
    grades: '400 | 450 | 500',
    country: 'Германия',
    hardness: '370 - 540',
    thickness: 'от 6 мм до 120 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм', '3000мм х 6000мм'],
  },
  sidur: {
    name: 'Sidur',
    grades: '400 | 450 | 500',
    country: 'Словения',
    hardness: '360 - 540',
    thickness: 'от 8 мм до 110 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм'],
  },
  hardox: {
    name: 'Hardox',
    grades: '400 | 450 | 500 | 600',
    country: 'Швеция',
    hardness: '370 - 640',
    thickness: 'от 4 мм до 130 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм', '3000мм х 12000мм'],
  },
  magstrong: {
    name: 'Magstrong',
    grades: '400 | 450 | 500',
    country: 'Бельгия',
    hardness: '360 - 530',
    thickness: 'от 6 мм до 100 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм'],
  },
  nm: {
    name: 'NM',
    grades: '400 | 450 | 500',
    country: 'Финляндия',
    hardness: '370 - 540',
    thickness: 'от 8 мм до 100 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм'],
  },
  other: {
    name: 'Другие марки',
    grades: '400 | 450 | 500',
    country: 'Различные',
    hardness: '360 - 600',
    thickness: 'от 4 мм до 150 мм',
    sizes: ['2000мм х 6000мм', '2500мм х 6000мм', '3000мм х 6000мм'],
  },
};

export default function ProductTabs() {
  const [activeTab, setActiveTab] = useState('sidur');

  const tabs = [
    { id: 'dillidur', label: 'Dillidur' },
    { id: 'sidur', label: 'Sidur' },
    { id: 'hardox', label: 'Hardox' },
    { id: 'magstrong', label: 'Magstrong' },
    { id: 'nm', label: 'NM' },
    { id: 'other', label: 'Другие марки' },
  ];

  const product = productsData[activeTab];

  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <h2 className="text-3xl lg:text-4xl font-bold text-neutral-900 mb-12 text-center lg:text-left">
          Какие стали мы можем предложить:
        </h2>

        {/* Tabs */}
        <div className="border-b border-neutral-300 mb-12 overflow-x-auto">
          <div className="flex gap-8 min-w-max">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`pb-4 font-semibold text-base transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'text-[#c20e0d] border-b-2 border-[#c20e0d]'
                    : 'text-neutral-900 hover:text-[#c20e0d]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Product Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-neutral-900 mb-4">{product.name}</h3>
              <p className="text-xl text-neutral-600">{product.grades}</p>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-neutral-200">
                <span className="font-semibold text-neutral-900">Страна производитель:</span>
                <span className="text-neutral-600">{product.country}</span>
              </div>

              <div className="flex justify-between items-center py-3 border-b border-neutral-200">
                <span className="font-semibold text-neutral-900">Твёрдость, HBW:</span>
                <span className="text-neutral-600">{product.hardness}</span>
              </div>

              <div className="flex justify-between items-center py-3 border-b border-neutral-200">
                <span className="font-semibold text-neutral-900">Толщина:</span>
                <span className="text-neutral-600">{product.thickness}</span>
              </div>

              <div className="flex justify-between items-start py-3 border-b border-neutral-200">
                <span className="font-semibold text-neutral-900">Стандартный размер:</span>
                <div className="text-right text-neutral-600">
                  {product.sizes.map((size, index) => (
                    <div key={index}>{size}</div>
                  ))}
                </div>
              </div>
            </div>

            <button className="bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-bold px-8 py-4 rounded-full transition-colors">
              Проверить наличие
            </button>
          </div>

          {/* Right - Product Image */}
          <div className="relative">
            <img
              src={steelImage}
              alt={product.name}
              className="w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}