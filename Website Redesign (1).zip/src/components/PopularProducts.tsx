import React from 'react';

interface Product {
  id: number;
  name: string;
  image: string;
  availability: 'high' | 'medium' | 'low';
}

const products: Product[] = [
  {
    id: 1,
    name: 'Лист Rexard 450 10мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'low',
  },
  {
    id: 2,
    name: 'Лист Rexard 450 12мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'medium',
  },
  {
    id: 3,
    name: 'Лист Sidur 450 20мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'medium',
  },
  {
    id: 4,
    name: 'Лист Sidur 500 10мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'low',
  },
  {
    id: 5,
    name: 'Лист Dillidur 500 20мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'medium',
  },
  {
    id: 6,
    name: 'Лист Hardox 450 10мм 2000ммx6000мм',
    image: 'https://images.unsplash.com/photo-1669643220202-b287116bd02f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXQlMjB0ZXh0dXJlJTIwYnJvd258ZW58MXx8fHwxNzY5NzEzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    availability: 'high',
  },
];

const AvailabilityIndicator = ({ level }: { level: 'high' | 'medium' | 'low' }) => {
  const bars = 3;
  const filledBars = level === 'high' ? 3 : level === 'medium' ? 2 : 1;

  return (
    <div className="flex gap-1 items-center justify-center">
      {Array.from({ length: bars }).map((_, index) => (
        <div
          key={index}
          className={`w-3 h-6 rounded-sm ${
            index < filledBars
              ? level === 'high'
                ? 'bg-green-500'
                : level === 'medium'
                ? 'bg-orange-500'
                : 'bg-red-500'
              : 'bg-neutral-300'
          }`}
        />
      ))}
    </div>
  );
};

const sideImages = [
  'https://images.unsplash.com/photo-1661069387900-54d5843b704d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVlbCUyMG1ldGFsJTIwc2hlZXRzJTIwc3RhY2tlZCUyMGluZHVzdHJpYWx8ZW58MXx8fHwxNzY5NzQ5NjM0fDA&ixlib=rb-4.1.0&q=80&w=1080',
  'https://images.unsplash.com/photo-1747999461210-a56f72294428?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZXRhbCUyMGZhY3RvcnklMjB3b3JrZXIlMjB3ZWxkaW5nJTIwaW5kdXN0cmlhbHxlbnwxfHx8fDE3Njk3NDk2MzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
  'https://images.unsplash.com/photo-1763926025477-423847028860?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXJlaG91c2UlMjBtZXRhbCUyMHN0ZWVsJTIwc3RvcmFnZXxlbnwxfHx8fDE3Njk3NDk2MzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
];

export default function PopularProducts() {
  return (
    <section className="bg-neutral-50 py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <h2 className="text-3xl lg:text-4xl font-bold text-neutral-900 mb-12">
          Популярные позиции у нас на складе:
        </h2>

        <div className="grid lg:grid-cols-[2fr,1fr] gap-8">
          {/* Table */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-neutral-200">
                    <th className="text-left py-4 px-6 font-semibold text-neutral-900">Номенклатура</th>
                    <th className="text-center py-4 px-6 font-semibold text-neutral-900 w-32">Наличие</th>
                    <th className="text-center py-4 px-6 font-semibold text-neutral-900 w-40">Цена</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product) => (
                    <tr key={product.id} className="border-b border-neutral-200 hover:bg-neutral-50 transition-colors">
                      <td className="py-4 px-6">
                        <span className="text-neutral-900">{product.name}</span>
                      </td>
                      <td className="py-4 px-6">
                        <AvailabilityIndicator level={product.availability} />
                      </td>
                      <td className="py-4 px-6 text-center">
                        <button className="text-blue-600 hover:text-blue-700 font-medium underline">
                          Запросить цену
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-neutral-200">
              {products.map((product) => (
                <div key={product.id} className="p-4 space-y-3">
                  <p className="font-medium text-neutral-900 mb-2">{product.name}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-neutral-500 mb-1">Наличие:</p>
                      <AvailabilityIndicator level={product.availability} />
                    </div>
                    <button className="text-blue-600 hover:text-blue-700 text-sm font-medium underline">
                      Запросить цену
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Side Images */}
          <div className="hidden lg:flex flex-col gap-4">
            {sideImages.map((image, index) => (
              <div key={index} className="h-full rounded-xl overflow-hidden shadow-md">
                <img
                  src={image}
                  alt={`Industrial image ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <div className="flex justify-center mt-12">
          <button className="bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-bold px-12 py-4 rounded-full text-lg transition-colors shadow-lg hover:shadow-xl">
            Запросить цену других позиций
          </button>
        </div>
      </div>
    </section>
  );
}