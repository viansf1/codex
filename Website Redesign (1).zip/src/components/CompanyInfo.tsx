import React from 'react';
import { CheckCircle } from 'lucide-react';

export default function CompanyInfo() {
  return (
    <section className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-[30%] min-w-[300px]">
          <p className="text-neutral-700 mb-6 leading-relaxed">
            Компания E&P специализируется на поставках высококачественных износостойких листов 
            ведущих мировых производителей. Мы работаем напрямую с заводами, что позволяет нам 
            предлагать лучшие цены на рынке.
          </p>
          
          <ul className="space-y-3">
            <li className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-[#c20e0d] flex-shrink-0 mt-0.5" />
              <span className="text-neutral-700">
                Более 15 лет опыта работы с промышленными предприятиями
              </span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-[#c20e0d] flex-shrink-0 mt-0.5" />
              <span className="text-neutral-700">
                Собственная логистическая сеть для быстрой доставки по всей России
              </span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
