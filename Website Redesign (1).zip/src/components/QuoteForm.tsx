import React, { useState } from 'react';
import { Coins } from 'lucide-react';

export default function QuoteForm() {
  const [formData, setFormData] = useState({
    companyName: '',
    nomenclature: '',
    contactName: '',
    phone: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Handle form submission
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section className="relative overflow-hidden py-16 lg:py-24">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1720036236697-018370867320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwbWV0YWwlMjBmYWN0b3J5JTIwbWFjaGluZXJ5JTIwZGFya3xlbnwxfHx8fDE3Njk3MTMyMzB8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Industrial background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-neutral-900/90"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="inline-block mb-4">
            <span className="bg-[#c20e0d] text-white font-bold px-4 py-2 rounded text-sm">
              КП за 30 минут!
            </span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-2">
            Хотите узнать наши спецпредложения и получить индивидуальное КП{' '}
            <span className="text-[#c20e0d]">всего за 30 минут</span>?
          </h2>
        </div>

        <div className="grid lg:grid-cols-[1fr,1fr] gap-8 lg:gap-12 items-start">
          {/* Form */}
          <div className="bg-white rounded-2xl p-6 shadow-2xl">
            <div className="inline-block mb-4">
              <div className="flex items-center gap-2 bg-[#c20e0d] text-white font-semibold px-4 py-2 rounded-lg text-sm">
                <Coins className="w-4 h-4" />
                <span>Скидки для производственных компаний!</span>
              </div>
            </div>

            <h3 className="text-xl font-bold text-neutral-900 mb-4">
              Получите индивидуальную стоимость с текущими скидками:
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Company Name */}
              <div>
                <label className="block text-sm font-semibold text-neutral-900 mb-2">
                  Название компании и ИНН:
                </label>
                <input
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  placeholder="ООО ЗаводМаш, ИНН 1234567889"
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none text-neutral-900"
                  required
                />
              </div>

              {/* Nomenclature */}
              <div>
                <label className="block text-sm font-semibold text-neutral-900 mb-2">
                  Номенклатура и количество:
                </label>
                <textarea
                  name="nomenclature"
                  value={formData.nomenclature}
                  onChange={handleChange}
                  placeholder="Например, Hardox 450 10мм 2000мм х 6000 мм — 5 тонн"
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none text-neutral-900 resize-none"
                  rows={2}
                  required
                />
              </div>

              {/* Contact Name and Phone */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-neutral-900 mb-2">
                    Ваше имя:
                  </label>
                  <input
                    type="text"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleChange}
                    placeholder="Иван Иванов"
                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none text-neutral-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-neutral-900 mb-2">
                    Телефон:
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+7 (000) 000-00-00"
                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#c20e0d] focus:border-transparent outline-none text-neutral-900"
                    required
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-[#c20e0d] hover:bg-[#a00c0b] text-white font-bold py-4 rounded-xl transition-colors text-lg"
              >
                Получить расчёт стоимости
              </button>

              <p className="text-xs text-neutral-500 text-center">
                Нажимая на кнопку, вы соглашаетесь с политикой обработки данных
              </p>
            </form>
          </div>

          {/* Benefits */}
          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="bg-[#c20e0d] rounded-full p-3 flex-shrink-0">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">
                  Доставка своей системной логистикой прямо до вашего объекта
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="bg-[#c20e0d] rounded-full p-3 flex-shrink-0">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">
                  Лучшая цена от 98 основных заводов
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="bg-[#c20e0d] rounded-full p-3 flex-shrink-0">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">
                  Лучшая цена с индивидуальными скидками
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}