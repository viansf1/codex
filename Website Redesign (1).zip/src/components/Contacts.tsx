import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

export default function Contacts() {
  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl lg:text-4xl font-bold text-neutral-900 mb-12">
          Контакты
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Phone */}
          <div className="flex gap-4">
            <div className="bg-[#c20e0d] rounded-full p-4 flex-shrink-0 h-fit">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 mb-2">Телефон</h3>
              <a href="tel:+74991130000" className="text-neutral-600 hover:text-[#c20e0d] transition-colors">
                +7 (499) 113-00-00
              </a>
            </div>
          </div>

          {/* Email */}
          <div className="flex gap-4">
            <div className="bg-[#c20e0d] rounded-full p-4 flex-shrink-0 h-fit">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 mb-2">Email</h3>
              <a href="mailto:zakaz@hard-met.ru" className="text-neutral-600 hover:text-[#c20e0d] transition-colors">
                zakaz@hard-met.ru
              </a>
            </div>
          </div>

          {/* Address */}
          <div className="flex gap-4">
            <div className="bg-[#c20e0d] rounded-full p-4 flex-shrink-0 h-fit">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 mb-2">Адрес</h3>
              <p className="text-neutral-600">
                Москва, ул. Промышленная, д. 1
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
